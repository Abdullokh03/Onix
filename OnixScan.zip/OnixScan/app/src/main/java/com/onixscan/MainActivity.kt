package com.onixscan

import android.Manifest
import android.bluetooth.BluetoothManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private val obd = Obd()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        setContent { App(obd, adapter) }
    }
    override fun onDestroy() { obd.close(); super.onDestroy() }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chart(data: List<Double>, max: Double, modifier: Modifier) {
    val c = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        if (data.size > 1) {
            val dx = size.width / (data.size - 1)
            fun y(v: Double) = size.height * (1 - (v / max).toFloat().coerceIn(0f, 1f))
            for (i in 1 until data.size) drawLine(c, Offset((i - 1) * dx, y(data[i - 1])), Offset(i * dx, y(data[i])), 3f)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun App(obd: Obd, adapter: android.bluetooth.BluetoothAdapter?) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("s", 0) }
    var theme by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
    var disp by remember { mutableStateOf(prefs.getString("disp", "1.2")!!) }
    val scheme = when (theme) { 1 -> lightColorScheme(); 2 -> darkColorScheme(background = Color.Black, surface = Color.Black); else -> darkColorScheme() }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Не подключено") }
    var connected by remember { mutableStateOf(false) }
    val values = remember { mutableStateMapOf<String, Double>() }
    val hist = remember { mutableStateMapOf<String, List<Double>>() }
    val selected = remember { mutableStateListOf("0C", "0D", "05", "04") }
    val dtcs = remember { mutableStateListOf<String>() }
    val freeze = remember { mutableStateMapOf<String, Double?>() }
    var query by remember { mutableStateOf("") }
    var run by remember { mutableStateOf(false) }
    var armed by remember { mutableStateOf(false) }
    var t0 by remember { mutableLongStateOf(0) }
    var result by remember { mutableStateOf<Double?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var vin by remember { mutableStateOf("—") }
    var lh by remember { mutableStateOf<Double?>(null) }
    var lp100 by remember { mutableStateOf<Double?>(null) }
    var dist by remember { mutableDoubleStateOf(0.0) }
    var fuel by remember { mutableDoubleStateOf(0.0) }
    var rec by remember { mutableStateOf(false) }
    val rows = remember { mutableStateListOf<String>() }
    var script by remember { mutableStateOf("") }
    val slog = remember { mutableStateListOf<String>() }
    var sjob by remember { mutableStateOf<Job?>(null) }
    val curTab by rememberUpdatedState(tab)
    val curRec by rememberUpdatedState(rec)
    val header = "time;" + PIDS.joinToString(";") { it.name } + ";L/100km"

    fun poll() = scope.launch {
        var last = System.nanoTime()
        while (isActive && connected) {
            val spd = obd.read(PIDS[1]) ?: continue
            values["0D"] = spd
            if (spd == 0.0) { run = false; armed = true }
            if (armed && spd > 0) { run = true; armed = false; t0 = System.nanoTime(); result = null }
            if (run && spd >= 100) { result = (System.nanoTime() - t0) / 1e9; run = false }
            if (curTab == 7) continue
            for (id in (selected + listOf("10", "0B", "0C", "0F")).distinct()) if (id != "0D")
                PIDS.first { it.id == id }.let { p -> obd.read(p)?.let { values[id] = it } }
            val now = System.nanoTime(); val dt = (now - last) / 1e9; last = now
            val d = disp.toDoubleOrNull() ?: 1.2
            val maf = values["10"] ?: run {
                val rpm = values["0C"]; val map = values["0B"]; val iat = values["0F"]
                if (rpm != null && map != null && iat != null) map * rpm / (iat + 273.15) / 2 / 60 * 0.85 * d * 28.97 / 8.314 else null
            }
            if (maf != null) {
                val l = maf * 3600 / (14.7 * 745); lh = l
                lp100 = if (spd > 3) l / spd * 100 else null
                fuel += l * dt / 3600
            }
            dist += spd * dt / 3600
            for (id in selected) values[id]?.let { hist[id] = (hist[id].orEmpty() + it).takeLast(120) }
            if (curRec) rows.add(System.currentTimeMillis().toString() + ";" +
                PIDS.joinToString(";") { values[it.id]?.let { v -> "%.2f".format(v) } ?: "" } + ";" + (lp100?.let { "%.2f".format(it) } ?: ""))
        }
    }

    val names = listOf("Панель", "Графики", "Ошибки", "Стоп-кадр", "Расход", "Поездка", "Справочник", "0–100", "Свет", "Связь", "Настройки")
    MaterialTheme(colorScheme = scheme) { Surface { Scaffold(topBar = {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            names.forEachIndexed { i, n -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(n, fontSize = 12.sp) }) }
        }
    }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp).fillMaxSize()) {
            when (tab) {
                0 -> {
                    Text(status)
                    FlowRow { PIDS.forEach { p ->
                        FilterChip(selected = p.id in selected, onClick = { if (p.id in selected) selected.remove(p.id) else selected.add(p.id) },
                            label = { Text(p.name, fontSize = 11.sp) }, modifier = Modifier.padding(2.dp)) } }
                    LazyColumn { items(PIDS.filter { it.id in selected }) { p ->
                        val v = values[p.id]
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(12.dp)) {
                            Text(p.name)
                            Text(if (v == null) "—" else "%.1f %s".format(v, p.unit), fontSize = 32.sp)
                            LinearProgressIndicator(progress = { ((v ?: 0.0) / p.max).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        } } } }
                }
                1 -> LazyColumn { items(PIDS.filter { it.id in selected }) { p ->
                    Text("${p.name} (${p.unit})", Modifier.padding(top = 8.dp))
                    Chart(hist[p.id].orEmpty(), p.max, Modifier.fillMaxWidth().height(90.dp))
                } }
                2 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row { Button(onClick = { scope.launch { dtcs.clear(); dtcs.addAll(obd.dtcs("03") + obd.dtcs("07")); status = "Найдено: ${dtcs.size}" } }, enabled = connected) { Text("Считать") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { confirmClear = true }, enabled = connected) { Text("Стереть") } }
                    if (dtcs.isEmpty()) Text("Ошибок нет / не считывались")
                    dtcs.forEach { Text("$it — ${DTC_INFO[it] ?: "нет в справочнике"}", Modifier.padding(vertical = 6.dp)) }
                }
                3 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row { Button(onClick = { scope.launch { PIDS.forEach { freeze[it.id] = obd.freeze(it) } } }, enabled = connected) { Text("Считать стоп-кадр") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { share(ctx, PIDS.joinToString("\n") { "${it.name}: ${freeze[it.id] ?: "—"} ${it.unit}" }, "Freeze frame") }) { Text("Экспорт") } }
                    Text("Данные в момент появления ошибки. Многие ЭБУ отвечают только при наличии ошибки.")
                    PIDS.forEach { Text("${it.name}: ${freeze[it.id]?.let { v -> "%.1f".format(v) } ?: "—"} ${it.unit}", Modifier.padding(vertical = 4.dp)) }
                }
                4 -> Column {
                    Text("Сейчас: ${lh?.let { "%.1f л/ч".format(it) } ?: "—"}", fontSize = 24.sp)
                    Text("${lp100?.let { "%.1f".format(it) } ?: "—"} л/100 км", fontSize = 40.sp)
                    Text("Пройдено: %.2f км".format(dist))
                    Text("Израсходовано: %.2f л".format(fuel))
                    Text("Средний: ${if (dist > 0.1) "%.1f".format(fuel / dist * 100) else "—"} л/100 км")
                    OutlinedButton(onClick = { dist = 0.0; fuel = 0.0 }) { Text("Сбросить") }
                    Text("Расчёт по MAF или по MAP при его отсутствии (оценка, бензин).")
                }
                5 -> Column {
                    Button(onClick = { rec = !rec }, enabled = connected) { Text(if (rec) "Остановить запись" else "Начать запись") }
                    Text("Записей: ${rows.size}")
                    Row { Button(onClick = { share(ctx, header + "\n" + rows.joinToString("\n"), "Trip log CSV") }, enabled = rows.isNotEmpty()) { Text("Экспорт CSV") }
                        Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { rows.clear() }) { Text("Очистить") } }
                }
                6 -> Column {
                    OutlinedTextField(query, { query = it.uppercase() }, label = { Text("Код или слово") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn { items(DTC_INFO.filter { query.isBlank() || it.key.contains(query) || it.value.uppercase().contains(query) }.toList()) { (k, v) ->
                        Text("$k — $v", Modifier.padding(vertical = 6.dp)) } }
                }
                7 -> Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Скорость: ${values["0D"]?.toInt() ?: "—"} км/ч", fontSize = 24.sp)
                    Text(when { result != null -> "%.2f с".format(result); run -> "Разгон…"; armed -> "Готово, жмите газ"; else -> "Остановитесь" }, fontSize = 48.sp)
                    Text("Замер 0–100 км/ч. Только на закрытой трассе!")
                }
                8 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Сценарий света. Каждая строка: ЗАГОЛОВОК КОМАНДА ПАУЗА_мс, например «7E0 2F0001 500» (пример формата, не рабочая команда). Нужные команды для BCM Onix нужно найти самому. Только при заглушенном двигателе, на свой риск.")
                    OutlinedTextField(script, { script = it }, modifier = Modifier.fillMaxWidth().height(160.dp), label = { Text("Строки сценария") })
                    Row { Button(enabled = connected && sjob?.isActive != true, onClick = { slog.clear(); sjob = scope.launch {
                        for (line in script.lines().filter { it.isNotBlank() }) {
                            val p = line.trim().split(Regex("\\s+")); if (p.size < 2) continue
                            if (p[0] != "-") obd.send("ATSH" + p[0])
                            slog.add("${p[1]} → ${obd.send(p[1])}")
                            delay(p.getOrNull(2)?.toLongOrNull() ?: 300)
                        } } }) { Text("Запуск") }
                        Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { sjob?.cancel() }) { Text("Стоп") } }
                    slog.forEach { Text(it) }
                }
                9 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Сначала спарьте ELM327 в настройках Bluetooth (PIN 1234 / 0000)")
                    adapter?.bondedDevices?.toList().orEmpty().forEach { d ->
                        @Suppress("MissingPermission")
                        Button(onClick = { scope.launch { status = "Подключение…"
                            runCatching { obd.connect(d) }.onSuccess { connected = true; status = "Подключено: ${d.name}"; poll() }.onFailure { status = "Ошибка: ${it.message}" } } },
                            Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(d.name ?: d.address) } }
                    Text(status)
                    Button(onClick = { scope.launch { vin = obd.vinParsed() } }, enabled = connected) { Text("Считать VIN") }
                    Text("VIN: $vin", fontSize = 20.sp)
                }
                10 -> Column {
                    Text("Тема")
                    Row { listOf("Тёмная", "Светлая", "AMOLED").forEachIndexed { i, n ->
                        FilterChip(selected = theme == i, onClick = { theme = i; prefs.edit().putInt("theme", i).apply() }, label = { Text(n) }, modifier = Modifier.padding(end = 6.dp)) } }
                    OutlinedTextField(disp, { disp = it; prefs.edit().putString("disp", it).apply() }, label = { Text("Объём двигателя, л (для оценки расхода)") }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    } } }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false },
        confirmButton = { TextButton(onClick = { confirmClear = false; scope.launch { obd.clearDtc(); dtcs.clear(); status = "Ошибки стёрты" } }) { Text("Стереть") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        title = { Text("Стереть ошибки?") }, text = { Text("Также сбросятся мониторы готовности.") })
}
