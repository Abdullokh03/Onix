package com.onixscan

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

data class Pid(val id: String, val name: String, val unit: String, val max: Double, val f: (IntArray) -> Double)

val PIDS = listOf(
    Pid("0C", "Обороты", "об/мин", 7000.0) { (it[0] * 256 + it[1]) / 4.0 },
    Pid("0D", "Скорость", "км/ч", 220.0) { it[0].toDouble() },
    Pid("05", "Охл. жидкость", "°C", 120.0) { it[0] - 40.0 },
    Pid("04", "Нагрузка", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("11", "Дроссель", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("0F", "Впуск. воздух", "°C", 80.0) { it[0] - 40.0 },
    Pid("10", "MAF", "г/с", 100.0) { (it[0] * 256 + it[1]) / 100.0 },
    Pid("0B", "MAP", "кПа", 255.0) { it[0].toDouble() },
    Pid("42", "Напряжение", "В", 16.0) { (it[0] * 256 + it[1]) / 1000.0 },
    Pid("2F", "Топливо", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("5C", "Масло", "°C", 150.0) { it[0] - 40.0 },
)

class Obd {
    private var sock: BluetoothSocket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null

    @SuppressLint("MissingPermission")
    suspend fun connect(d: BluetoothDevice) = withContext(Dispatchers.IO) {
        val s = d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect(); sock = s; inp = s.inputStream; out = s.outputStream
        for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) send(c)
    }

    fun close() { runCatching { sock?.close() }; sock = null }

    suspend fun send(cmd: String): String = withContext(Dispatchers.IO) {
        out!!.write((cmd + "\r").toByteArray()); out!!.flush()
        val sb = StringBuilder()
        while (true) { val n = inp!!.read(); if (n < 0 || n.toChar() == '>') break; sb.append(n.toChar()) }
        sb.toString().trim()
    }

    suspend fun read(p: Pid): Double? = runCatching {
        val r = send("01" + p.id).replace(" ", "").replace("\r", "").replace("\n", "")
        val i = r.indexOf("41" + p.id); if (i < 0) return null
        val hex = r.substring(i + 4)
        p.f(IntArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16) })
    }.getOrNull()

    suspend fun dtcs(mode: String = "03"): List<String> {
        val resp = (mode.toInt(16) + 0x40).toString(16).uppercase()
        val res = mutableListOf<String>()
        for (line in send(mode).split("\r", "\n")) {
            var h = line.replace(" ", ""); if (!h.startsWith(resp)) continue
            h = h.drop(2)
            for (i in 0 until h.length / 4) {
                val w = h.substring(i * 4, i * 4 + 4); if (w == "0000") continue
                val a = w.substring(0, 1).toInt(16)
                res += "PCBU"[a shr 2].toString() + (a and 3) + w.substring(1)
            }
        }
        return res.distinct()
    }

    suspend fun clearDtc() = send("04")
    suspend fun vin(): String = send("0902")
}

val DTC_INFO = mapOf(
    "P0011" to "Фаза распредвала: опережение (впуск), банк 1",
    "P0016" to "Корреляция коленвал/распредвал",
    "P0100" to "Цепь датчика MAF",
    "P0105" to "Цепь датчика MAP",
    "P0112" to "Датчик темп. впуска: низкий сигнал",
    "P0117" to "Датчик темп. ОЖ: низкий сигнал",
    "P0118" to "Датчик темп. ОЖ: высокий сигнал",
    "P0122" to "Датчик положения дросселя: низкий сигнал",
    "P0131" to "Лямбда-зонд 1: низкое напряжение",
    "P0171" to "Бедная смесь (банк 1)",
    "P0172" to "Богатая смесь (банк 1)",
    "P0201" to "Форсунка цилиндра 1: цепь",
    "P0300" to "Пропуски зажигания (случайные)",
    "P0301" to "Пропуски зажигания: цилиндр 1",
    "P0302" to "Пропуски зажигания: цилиндр 2",
    "P0303" to "Пропуски зажигания: цилиндр 3",
    "P0304" to "Пропуски зажигания: цилиндр 4",
    "P0335" to "Датчик положения коленвала: цепь",
    "P0340" to "Датчик положения распредвала: цепь",
    "P0420" to "Эффективность катализатора ниже нормы",
    "P0444" to "Клапан адсорбера: цепь",
    "P0500" to "Датчик скорости авто",
    "P0562" to "Низкое напряжение бортсети",
    "P0601" to "Ошибка памяти ЭБУ",
    "U0100" to "Нет связи с ЭБУ двигателя",
)
