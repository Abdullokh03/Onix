package com.onixscan

import android.content.Context
import android.content.Intent

suspend fun Obd.vinParsed(): String {
    var hex = ""
    for (l in send("0902").split("\r", "\n")) {
        val t = l.trim().replace(" ", "").replace(Regex("^[0-9A-F]:"), "")
        if (t.length > 3) hex += t
    }
    val i = hex.indexOf("4902"); if (i < 0 || hex.length < i + 6) return "нет данных"
    val d = hex.substring(i + 6)
    val s = (0 until d.length / 2).map { d.substring(it * 2, it * 2 + 2).toInt(16) }
        .filter { it in 0x30..0x5A }.map { it.toChar() }.joinToString("")
    return s.ifEmpty { "нет данных" }
}

suspend fun Obd.freeze(p: Pid): Double? = runCatching {
    val r = send("02" + p.id + "00").replace(" ", "").replace("\r", "").replace("\n", "")
    val i = r.indexOf("42" + p.id + "00"); if (i < 0) return null
    val hex = r.substring(i + 6)
    p.f(IntArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16) })
}.getOrNull()

fun share(c: Context, text: String, title: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text); putExtra(Intent.EXTRA_SUBJECT, title) }
    c.startActivity(Intent.createChooser(i, title))
}
